﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CATSTAGRAM.Data;
using CATSTAGRAM.Models;

namespace CATSTAGRAM.Controllers
{
    public class CatPhotosController : Controller
    {
        private readonly HomeDbContext _context;

        public CatPhotosController(HomeDbContext context)
        {
            _context = context;
        }

        // GET: CatPhotos
        public async Task<IActionResult> Index()
        {
              return _context.CatPhoto != null ? 
                          View(await _context.CatPhoto.ToListAsync()) :
                          Problem("Entity set 'HomeDbContext.CatPhoto'  is null.");
        }

        // GET: CatPhotos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.CatPhoto == null)
            {
                return NotFound();
            }

            var catPhoto = await _context.CatPhoto
                .FirstOrDefaultAsync(m => m.Id == id);
            if (catPhoto == null)
            {
                return NotFound();
            }

            return View(catPhoto);
        }

        // GET: CatPhotos/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CatPhotos/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,AuthorName,AuthorEmail,ImageTitle,ImageDescription,ImageFileName,ImageData,DateAdded,Comments")] CatPhoto catPhoto)
        {
            if (ModelState.IsValid)
            {
                _context.Add(catPhoto);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(catPhoto);
        }

        // GET: CatPhotos/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.CatPhoto == null)
            {
                return NotFound();
            }

            var catPhoto = await _context.CatPhoto.FindAsync(id);
            if (catPhoto == null)
            {
                return NotFound();
            }
            return View(catPhoto);
        }

        // POST: CatPhotos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,AuthorName,AuthorEmail,ImageTitle,ImageDescription,ImageFileName,ImageData,DateAdded,Comments")] CatPhoto catPhoto)
        {
            if (id != catPhoto.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(catPhoto);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CatPhotoExists(catPhoto.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(catPhoto);
        }

        // GET: CatPhotos/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.CatPhoto == null)
            {
                return NotFound();
            }

            var catPhoto = await _context.CatPhoto
                .FirstOrDefaultAsync(m => m.Id == id);
            if (catPhoto == null)
            {
                return NotFound();
            }

            return View(catPhoto);
        }

        // POST: CatPhotos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.CatPhoto == null)
            {
                return Problem("Entity set 'HomeDbContext.CatPhoto'  is null.");
            }
            var catPhoto = await _context.CatPhoto.FindAsync(id);
            if (catPhoto != null)
            {
                _context.CatPhoto.Remove(catPhoto);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CatPhotoExists(int id)
        {
          return (_context.CatPhoto?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
