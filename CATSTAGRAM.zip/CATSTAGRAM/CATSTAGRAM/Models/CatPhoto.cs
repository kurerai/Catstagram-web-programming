﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace CATSTAGRAM.Models
{
    public class CatPhoto
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string AuthorName { get; set; }

        [Required]
        [EmailAddress]
        public string AuthorEmail { get; set; }

        [Required]
        public string ImageTitle { get; set; }

        [Required]
        public string ImageDescription { get; set; }

        [Required]
        [Display(Name = "Image")]
        public string ImageFileName { get; set; }

        [NotMapped]
        public IFormFile ImageFile { get; set; }

        public byte[] ImageData { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DateAdded { get; set; } = DateTime.Now;

        public string Comments { get; set; }
    }
}